describe('Example Test Suite', () => {
  it('should find and click a button', () => {
    cy.visit('https://example.com');
    cy.get('button').should('exist').click();
  });
});