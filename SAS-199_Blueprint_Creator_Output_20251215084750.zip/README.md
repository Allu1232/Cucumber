# Project Structure

This project includes Cypress test cases and supporting functions.

## Directory Structure

- cypress/
  - integration/
    - test_cases/
  - support/
    - functions/
