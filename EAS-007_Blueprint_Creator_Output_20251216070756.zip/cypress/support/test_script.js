// Cypress Test Script

// Supporting Function
function login(username, password) {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

// Test Case
describe('Login Test', () => {
  it('should log in with valid credentials', () => {
    cy.visit('https://example.com/login');
    login('testuser', 'password123');
    cy.url().should('include', '/dashboard');
  });
});