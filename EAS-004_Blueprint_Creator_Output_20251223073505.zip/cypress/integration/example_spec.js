// Example Cypress test case

describe('Example Test', () => {
  it('should visit the page', () => {
    cy.visit('https://example.com');
  });
});
