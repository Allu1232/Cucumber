// Cypress Test Script

describe('Sample Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.contains('Welcome to Example');
  });

  it('should have a login button', () => {
    cy.get('#login-button').should('be.visible');
  });
});
