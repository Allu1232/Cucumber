describe('Jira Test Suite', () => {
  it('should create a new Jira issue', () => {
    // Navigate to Jira
    cy.visit('https://jira.example.com');

    // Login
    cy.get('#username').type('your-username');
    cy.get('#password').type('your-password');
    cy.get('#login').click();

    // Create a new issue
    cy.contains('Create').click();
    cy.get('#summary').type('New issue summary');
    cy.get('#description').type('Description of the new issue');
    cy.get('#create-issue-submit').click();

    // Verify issue creation
    cy.contains('New issue summary').should('exist');
  });

  // Supporting function example
  const loginToJira = (username, password) => {
    cy.get('#username').type(username);
    cy.get('#password').type(password);
    cy.get('#login').click();
  };
});