// sample_test_spec.js

describe('Sample Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.contains('Example Domain');
  });

  it('should have a clickable link', () => {
    cy.get('a').should('have.attr', 'href').and('include', 'iana');
  });
});
