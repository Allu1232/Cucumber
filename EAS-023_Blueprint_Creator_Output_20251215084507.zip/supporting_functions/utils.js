// utils.js

// Utility function to log messages
function logMessage(message) {
  console.log(`[LOG]: ${message}`);
}

// Utility function to format date
function formatDate(date) {
  return new Date(date).toLocaleDateString();
}

// Exporting utility functions
module.exports = {
  logMessage,
  formatDate
};
