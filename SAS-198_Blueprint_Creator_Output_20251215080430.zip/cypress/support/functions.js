// functions.js

export function login() {
  cy.visit('/login');
  cy.get('#username').type('testuser');
  cy.get('#password').type('password');
  cy.get('#login-button').click();
}

export function logout() {
  cy.get('#logout-button').click();
}