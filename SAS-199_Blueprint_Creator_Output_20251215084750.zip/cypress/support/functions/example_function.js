// Cypress Supporting Function Example
function exampleFunction() {
  // Function implementation
  console.log('Example function executed');
}

module.exports = { exampleFunction };