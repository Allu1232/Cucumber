# Cypress Automation Project

This project is set up to use Cypress for end-to-end testing. It includes integration tests and supporting functions as per the blueprint guidelines.

## Project Structure

- `cypress/integration`: Contains test cases.
- `cypress/support`: Contains supporting functions.

## Getting Started

1. Install dependencies: `npm install`
2. Run tests: `npx cypress open`

## Cypress

Cypress is a JavaScript-based end-to-end testing framework. It is used for testing web applications by simulating user interactions.