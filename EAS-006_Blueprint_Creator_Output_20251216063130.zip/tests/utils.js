export const login = (username, password) => {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
};

export const checkElementVisible = (selector) => {
  cy.get(selector).should('be.visible');
};