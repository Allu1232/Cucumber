// Supporting Functions for Cypress Tests

function login(username, password) {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

function logout() {
  cy.get('#logout-button').click();
}

module.exports = { login, logout };
