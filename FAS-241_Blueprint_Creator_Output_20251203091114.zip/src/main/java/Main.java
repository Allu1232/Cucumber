package com.example.seleniumproject;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, Selenium!");
    }
}