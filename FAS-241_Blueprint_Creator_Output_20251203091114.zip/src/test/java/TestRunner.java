
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.testng.annotations.Test;

@RunWith(Cucumber.class)
@CucumberOptions(
  features = "src/test/resources/features",
  glue = {"stepDefinitions"},
  plugin = {"pretty", "html:target/cucumber-reports"},
  monochrome = true
)
public class TestRunner {
  
  @Test
  public void runCucumberTests() {
    // This method will run Cucumber test scenarios
  }
}