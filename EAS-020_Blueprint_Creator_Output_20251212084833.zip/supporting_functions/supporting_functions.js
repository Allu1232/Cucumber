// Supporting Functions for Xray Data Model Tests

function validateModelStructure() {
  // Function to validate the structure of the xray data model
  cy.get('#model-structure').should('exist');
}

function performCrudOperations() {
  // Function to perform CRUD operations on the xray data model
  cy.request('POST', '/api/xray', { name: 'New Model' }).then((response) => {
    expect(response.status).to.eq(201);
  });
  // Further CRUD operations
}

module.exports = { validateModelStructure, performCrudOperations }; 