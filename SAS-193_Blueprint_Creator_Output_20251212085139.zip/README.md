# Project Structure

This project contains test cases for Xray using Cypress.
