// example_test.js
// Cypress Test Case

describe('Example Test Suite', () => {
  it('should visit the homepage', () => {
    cy.visit('https://example.com');
    cy.get('h1').should('contain', 'Example Domain');
  });

  it('should have a link to more information', () => {
    cy.get('a').should('have.attr', 'href', 'https://www.iana.org/domains/example');
  });
});