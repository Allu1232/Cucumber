# Project Structure

This project contains Cypress tests and supporting functions.
