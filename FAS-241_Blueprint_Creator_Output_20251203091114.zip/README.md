# FAS-241 Blueprint Creator

This project is set up using Selenium WebDriver with Java, TestNG, and Cucumber.