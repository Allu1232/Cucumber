# Project Structure

This project contains the Cypress test setup and supporting functions.
