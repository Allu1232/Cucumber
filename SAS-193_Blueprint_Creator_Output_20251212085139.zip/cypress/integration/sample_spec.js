// Sample Cypress Test Case

describe('Xray Test Suite', () => {
  it('should perform a sample test', () => {
    cy.visit('https://example.com');
    cy.get('#sample-element').should('be.visible');
    cy.get('#sample-button').click();
    cy.url().should('include', '/next-page');
  });
});
