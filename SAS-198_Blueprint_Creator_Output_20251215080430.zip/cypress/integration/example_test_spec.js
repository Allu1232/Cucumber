// example_test_spec.js

// Import necessary functions
import { login, logout } from '../support/functions';

describe('Example Test Suite', () => {
  before(() => {
    // Setup code if needed
  });

  beforeEach(() => {
    // Code to run before each test
    login();
  });

  afterEach(() => {
    // Code to run after each test
    logout();
  });

  it('should perform a sample test', () => {
    cy.visit('/');
    cy.contains('Welcome').should('be.visible');
  });
});
