# Project Structure

This project follows the guidelines for a Cypress testing framework.

## Directories and Files

- `cypress/`
  - Contains test cases and supporting functions.
- `cypress/integration/`
  - Test cases go here.
- `cypress/support/`
  - Supporting functions and utilities.
- `cypress/fixtures/`
  - Test data.

## Setup

Ensure all dependencies are installed before running tests.