# Project Overview

This project uses Cypress for end-to-end testing.

## Running Tests

To run the tests, use the following command:

```
npx cypress open
```

This will open the Cypress Test Runner where you can execute the test cases.