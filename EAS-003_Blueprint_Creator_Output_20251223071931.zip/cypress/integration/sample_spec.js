describe('Sample Test Suite', () => {
  it('Visits the initial project page', () => {
    cy.visit('/');
    cy.contains('Welcome to Cypress');
  });

  it('Checks for a specific element', () => {
    cy.get('.element-class').should('be.visible');
  });
});