# Xray Project

This project contains the test automation scripts for the Xray application.