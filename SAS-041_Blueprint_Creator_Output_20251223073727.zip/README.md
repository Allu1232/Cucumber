# Project Setup

This project is configured to use Cypress for automation testing.

## Getting Started

1. Ensure Node.js is installed on your system.
2. Install Cypress by running `npm install cypress`.
3. Open Cypress Test Runner using `npx cypress open`.

## Test Cases

The test cases are located in the `cypress/integration` directory.

## Supporting Functions

Supporting functions are located in the `cypress/support` directory.

## Running Tests

To run tests, execute `npx cypress run` in the terminal.

## Configuration

Configuration files are located in the `cypress.json` file.

For more information, visit the [Cypress Documentation](https://docs.cypress.io/).