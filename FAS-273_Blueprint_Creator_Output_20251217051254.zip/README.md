# Project Structure

This project includes Selenium Web Driver, Java, TestNG, and Cucumber.
