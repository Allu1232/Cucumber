// Example Cypress test case

describe('Example Test', () => {
  it('should do something', () => {
    // test code here
  });
});