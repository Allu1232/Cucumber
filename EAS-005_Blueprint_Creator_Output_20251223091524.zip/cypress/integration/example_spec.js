describe('Example Test Suite', () => {
  it('Visits the Kitchen Sink', () => {
    cy.visit('https://example.cypress.io')
    cy.contains('type').click()
    cy.url().should('include', '/commands/actions')
    cy.get('.action-email').type('test@example.com')
    cy.get('.action-email').should('have.value', 'test@example.com')
  })
})