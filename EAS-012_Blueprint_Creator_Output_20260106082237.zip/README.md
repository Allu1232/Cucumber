# Cypress Project

This project contains Cypress test cases and supporting functions as per the blueprint guidelines. It is structured to facilitate automated testing using Cypress.

## Directory Structure

- **cypress/integration/**: Contains integration test cases.
- **cypress/support/**: Contains supporting functions for the test cases.

## Getting Started

To run the tests, ensure you have Node.js and Cypress installed. Use the command `cypress open` to start the Cypress Test Runner.
